package com.example.storyapp1.data.model

data class UserModel(
    val tokenAuth: String,
    val isLogin: Boolean
)
